archivo = open("archivo.txt" , "a")
archivo.write("hola")
archivo.close()
