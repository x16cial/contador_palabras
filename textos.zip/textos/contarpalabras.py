filename = 'archivo.txt'
try:
    with open(filename) as f_obj:
        contents = f_obj.read()
        print(contents)
except FileNotFoundError:
    msg = "no existe el archivo" + filename + "busca mejor"
    print(msg)
else:
    words = contents.split()
    num_words = len(words)
    print("el archivo " + filename + " tiene " + str(num_words) + " palabras")
