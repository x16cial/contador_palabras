
archivo = open("archivo.txt" , "w")
archivo.write("hola")
archivo.close()
