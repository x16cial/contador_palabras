
archivo = open("archivo.txt", "r")
linea = archivo.readline()
print(linea)
archivo.close()
