with open("archivo.txt" , "r+") as archivo:
    contenido = archivo.read()
    print(contenido)
    archivo.write("Esta es una nueva lista.")
