archivo = open("archivo.txt" , "a")
lineas = ["\nlinea 1\n" , "linea 2\n" , "linea 3\n"]
archivo.writelines(lineas)
